﻿using Microsoft.Win32;
using System;
using System.IO;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Media.Effects; // Necessário para DropShadowEffect

namespace WpfServoController
{
    public partial class MainWindow : Window
    {
        private SerialPort _serialPort = new SerialPort();
        private DispatcherTimer _autoModeTimer = new DispatcherTimer();
        private DispatcherTimer _dataLoggingTimer = new DispatcherTimer();
        private DispatcherTimer _performanceTimer = new DispatcherTimer();

        private long _energiaTotalRastreador = 0;
        private long _energiaTotalFixa = 0;
        private int _picoDeLuzValor = 0;
        private DateTime _picoDeLuzTimestamp;
        private double _fatorClimatico = 1.0;
        private string _logFilePath = "";
        private int _currentServoPos = 90;
        private int _currentLdrLeft = 0;
        private int _currentLdrRight = 0;
        
        public MainWindow()
        {
            InitializeComponent();
            LoadComPorts();
            _autoModeTimer.Interval = TimeSpan.FromMilliseconds(250);
            _autoModeTimer.Tick += AutoModeTimer_Tick;
            _dataLoggingTimer.Interval = TimeSpan.FromSeconds(30);
            _dataLoggingTimer.Tick += DataLoggingTimer_Tick;
            _performanceTimer.Interval = TimeSpan.FromSeconds(1);
            _performanceTimer.Tick += PerformanceTimer_Tick;
            UpdateUIState(false);
        }
        
        private void PerformanceTimer_Tick(object sender, EventArgs e)
        {
            int ldrLeftSimulado = (int)(_currentLdrLeft * _fatorClimatico);
            int ldrRightSimulado = (int)(_currentLdrRight * _fatorClimatico);
            int energiaInstantanea = ldrLeftSimulado + ldrRightSimulado;

            if (toggleAutoMode.IsChecked == true) { _energiaTotalRastreador += energiaInstantanea; }

            double anguloForaDoEixo = Math.Abs(_currentServoPos - 90);
            double fatorDePerda = Math.Cos(anguloForaDoEixo * Math.PI / 180.0);
            _energiaTotalFixa += (long)(energiaInstantanea * fatorDePerda);

            if (energiaInstantanea > _picoDeLuzValor)
            {
                _picoDeLuzValor = energiaInstantanea;
                _picoDeLuzTimestamp = DateTime.Now;
                txtPicoDeLuz.Text = _picoDeLuzTimestamp.ToString("HH:mm:ss");
            }
            
            txtEnergiaRastreador.Text = _energiaTotalRastreador.ToString("N0");
            txtEnergiaFixa.Text = _energiaTotalFixa.ToString("N0");
            
            if (_energiaTotalFixa > 0)
            {
                double ganho = ((double)_energiaTotalRastreador / _energiaTotalFixa - 1.0) * 100.0;
                txtGanhoPerformance.Text = $"{ganho:F1}%";
            }
            UpdateSunAnimation(energiaInstantanea);
        }

        private void CmbCondicaoClimatica_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbCondicaoClimatica.SelectedItem is ComboBoxItem selectedItem && _serialPort.IsOpen)
            {
                _fatorClimatico = double.Parse(selectedItem.Tag.ToString());
                LogEvent($"Simulação de clima: {selectedItem.Content} (Fator: {_fatorClimatico})");
            }
        }
        
        private void BtnResetEnergia_Click(object sender, RoutedEventArgs e)
        {
            _energiaTotalRastreador = 0; _energiaTotalFixa = 0; _picoDeLuzValor = 0;
            txtEnergiaRastreador.Text = "0"; txtEnergiaFixa.Text = "0";
            txtGanhoPerformance.Text = "0.0%"; txtPicoDeLuz.Text = "--:--:--";
            LogEvent("Contadores de performance zerados.");
        }

        private void UpdateSunAnimation(int lightIntensity)
        {
            // Mapeia a intensidade da luz (0-2046) para um tamanho (20-100)
            double minSize = 20;
            double maxSize = 100;
            double size = minSize + (lightIntensity / 2046.0) * (maxSize - minSize);
            SolAnimation.Width = size;
            SolAnimation.Height = size;
            
            // Centraliza a elipse no Canvas dinamicamente
            if (SunCanvas != null && SunCanvas.ActualWidth > 0 && SunCanvas.ActualHeight > 0)
            {
                Canvas.SetLeft(SolAnimation, (SunCanvas.ActualWidth / 2) - (size / 2));
                Canvas.SetTop(SolAnimation, (SunCanvas.ActualHeight / 2) - (size / 2));
            }
            
            // Mapeia a intensidade para cor e brilho (glow)
            if (SolAnimation.Effect is DropShadowEffect glow)
            {
                // Brilho aumenta com a luz, de um mínimo para um máximo
                double minBlurRadius = 10;
                double maxBlurRadius = 50;
                glow.BlurRadius = minBlurRadius + (lightIntensity / 2046.0) * (maxBlurRadius - minBlurRadius);
                glow.Color = Colors.Yellow; // Mantém a cor do brilho amarela
                glow.Opacity = 0.5 + (lightIntensity / 2046.0) * 0.5; // Opacidade do brilho aumenta com a luz
            }

            if (lightIntensity < 500) SolAnimation.Fill = new SolidColorBrush(Colors.LightYellow);
            else if (lightIntensity < 1200) SolAnimation.Fill = new SolidColorBrush(Colors.Orange);
            else SolAnimation.Fill = new SolidColorBrush(Colors.OrangeRed);
        }

        private void SunCanvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            // Garante que a animação seja centralizada quando o Canvas muda de tamanho
            UpdateSunAnimation(_currentLdrLeft + _currentLdrRight);
        }

        #region Código de Suporte (Funções de Conexão, Logging, etc.)
        private void UpdateUIState(bool isConnected)
        {
            btnConnect.IsEnabled = !isConnected; btnDisconnect.IsEnabled = isConnected; cmbComPorts.IsEnabled = !isConnected;
            toggleAutoMode.IsEnabled = isConnected; gbTestes.IsEnabled = isConnected; chkLogData.IsEnabled = isConnected;
            btnSaveCsv.IsEnabled = isConnected; btnChooseFile.IsEnabled = isConnected; btnResetEnergia.IsEnabled = isConnected;
            cmbCondicaoClimatica.IsEnabled = isConnected;
            if (isConnected)
            {
                _performanceTimer.Start();
                txtStatus.Text = $"Status: Conectado a {_serialPort.PortName}";
                txtStatus.Foreground = Brushes.Green;
                cmbCondicaoClimatica.SelectedIndex = 0; // Define o Sol Pleno como padrão ao conectar
            }
            else
            {
                _autoModeTimer.Stop(); _dataLoggingTimer.Stop(); _performanceTimer.Stop();
                _logFilePath = "";
                txtStatus.Text = "Status: Desconectado";
                txtStatus.Foreground = Brushes.Gray;
                if(toggleAutoMode != null) toggleAutoMode.IsChecked = false;
                if(chkLogData != null) chkLogData.IsChecked = false;
            }
        }
        
        private string ConvertLdrValueToDescription(int ldrValue) { if (ldrValue < 100) return "Escuro / Sombra"; if (ldrValue < 300) return "Luz Fraca"; if (ldrValue < 600) return "Luz Moderada"; if (ldrValue < 900) return "Luz Forte"; return "Luz Intensa"; }
        private void ParseAndDisplayData(string data) { data = data.Trim(); string[] parts = data.Split(','); foreach (string part in parts) { string[] keyValue = part.Split(':'); if (keyValue.Length == 2) { string key = keyValue[0]; if (int.TryParse(keyValue[1], out int value)) { switch (key) { case "LDR_L": _currentLdrLeft = value; txtLdrLeft.Text = value.ToString(); txtLdrLeftDesc.Text = ConvertLdrValueToDescription(value); break; case "LDR_R": _currentLdrRight = value; txtLdrRight.Text = value.ToString(); txtLdrRightDesc.Text = ConvertLdrValueToDescription(value); break; case "POS": _currentServoPos = value; txtServoPos.Text = value.ToString(); break; } } } } }
        private bool EnsureLogFileIsChosen() { if (string.IsNullOrEmpty(_logFilePath)) { return ChooseLogFile(); } return true; }
        private bool ChooseLogFile() { SaveFileDialog saveFileDialog = new SaveFileDialog { Filter = "Arquivo CSV (*.csv)|*.csv", FileName = "dados_solares.csv", Title = "Escolha onde salvar" }; if (saveFileDialog.ShowDialog() == true) { _logFilePath = saveFileDialog.FileName; LogEvent($"Arquivo de dados: {_logFilePath}"); if (!File.Exists(_logFilePath)) { string header = "Timestamp,PosicaoServo,LDR_Esquerdo,LDR_Direito,IncidenciaTotal,Diferenca" + Environment.NewLine; File.WriteAllText(_logFilePath, header); } return true; } return false; }
        private void DataLoggingTimer_Tick(object sender, EventArgs e) { if (toggleAutoMode.IsChecked == true) { LogDataToCsv(); } }
        private void LogDataToCsv() { if (!EnsureLogFileIsChosen()) return; try { string timestamp = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"); int incidenciaTotal = _currentLdrLeft + _currentLdrRight; int diferenca = _currentLdrLeft - _currentLdrRight; string dataLine = $"{timestamp},{_currentServoPos},{_currentLdrLeft},{_currentLdrRight},{incidenciaTotal},{diferenca}" + Environment.NewLine; File.AppendAllText(_logFilePath, dataLine); LogEvent($"Dados salvos em CSV."); } catch (Exception ex) { LogEvent($"ERRO ao salvar CSV: {ex.Message}"); } }
        private void ChkLogData_CheckedChanged(object sender, RoutedEventArgs e) { if (chkLogData.IsChecked == true) { if (EnsureLogFileIsChosen()) { _dataLoggingTimer.Start(); LogEvent("Gravação automática INICIADA."); } else { chkLogData.IsChecked = false; } } else { _dataLoggingTimer.Stop(); LogEvent("Gravação automática PARADA."); } }
        private void BtnSaveCsv_Click(object sender, RoutedEventArgs e) { LogEvent("Salvamento manual solicitado."); LogDataToCsv(); }
        private void BtnChooseFile_Click(object sender, RoutedEventArgs e) { ChooseLogFile(); }
        private void AutoModeTimer_Tick(object sender, EventArgs e) { int ldrLeftSimulado = (int)(_currentLdrLeft * _fatorClimatico); int ldrRightSimulado = (int)(_currentLdrRight * _fatorClimatico); int tolerancia = 30; double Kp = 0.05; int maxPasso = 5; int diferencaLuz = ldrLeftSimulado - ldrRightSimulado; if (Math.Abs(diferencaLuz) > tolerancia) { double ajuste = diferencaLuz * Kp; int tamanhoDoPasso = (int)Math.Clamp(ajuste, -maxPasso, maxPasso); if (tamanhoDoPasso == 0 && diferencaLuz > 0) tamanhoDoPasso = 1; if (tamanhoDoPasso == 0 && diferencaLuz < 0) tamanhoDoPasso = -1; int novaPosicao = _currentServoPos + tamanhoDoPasso; SendCommand($"P{novaPosicao}"); } }
        private async void SweepButton_Click(object sender, RoutedEventArgs e) { Button clickedButton = sender as Button; if (clickedButton == null) return; int targetAngle = int.Parse(clickedButton.Tag.ToString()); int startAngle = 90; int sweepSpeedDelay = 20; LogEvent($"Iniciando varredura de {startAngle}° para {targetAngle}°..."); SetControlsEnabled(false); SendCommand($"P{startAngle}"); await Task.Delay(1000); if (targetAngle < startAngle) { for (int i = startAngle; i >= targetAngle; i--) { SendCommand($"P{i}"); await Task.Delay(sweepSpeedDelay); } } else { for (int i = startAngle; i <= targetAngle; i++) { SendCommand($"P{i}"); await Task.Delay(sweepSpeedDelay); } } LogEvent("Varredura concluída."); SetControlsEnabled(true); }
        private void SetControlsEnabled(bool isEnabled) { toggleAutoMode.IsEnabled = isEnabled; gbTestes.IsEnabled = isEnabled; }
        private void LoadComPorts() { cmbComPorts.ItemsSource = SerialPort.GetPortNames(); if (cmbComPorts.Items.Count > 0) cmbComPorts.SelectedIndex = 0; }
        private void BtnRefreshPorts_Click(object sender, RoutedEventArgs e) { LoadComPorts(); }
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e) { try { string data = _serialPort.ReadLine(); Dispatcher.Invoke(() => ParseAndDisplayData(data)); } catch (Exception) { /* Ignora erros */ } }
        private void ToggleAutoMode_Checked(object sender, RoutedEventArgs e) { _autoModeTimer.Start(); gbTestes.IsEnabled = false; LogEvent("Rastreamento Automático INICIADO."); }
        private void ToggleAutoMode_Unchecked(object sender, RoutedEventArgs e) { _autoModeTimer.Stop(); gbTestes.IsEnabled = true; LogEvent("Rastreamento Automático PARADO."); }
        private void SendCommand(string command) { if (_serialPort.IsOpen) { try { _serialPort.WriteLine(command); } catch (Exception ex) { LogEvent($"Erro ao enviar comando: {ex.Message}"); } } }
        private void LogEvent(string message) { string logEntry = $"{DateTime.Now:HH:mm:ss}: {message}"; logListView.Items.Add(logEntry); logListView.ScrollIntoView(logListView.Items[logListView.Items.Count - 1]); }
        private void BtnConnect_Click(object sender, RoutedEventArgs e) { if (cmbComPorts.SelectedItem == null) { MessageBox.Show("Selecione uma porta COM."); return; } try { _serialPort.PortName = cmbComPorts.SelectedItem.ToString(); _serialPort.BaudRate = 9600; _serialPort.DataReceived += SerialPort_DataReceived; _serialPort.Open(); UpdateUIState(true); LogEvent($"Conectado com sucesso a {_serialPort.PortName}"); } catch (Exception ex) { MessageBox.Show($"Erro ao conectar: {ex.Message}"); } }
        private void BtnDisconnect_Click(object sender, RoutedEventArgs e) { if (_serialPort.IsOpen) { _serialPort.Close(); } UpdateUIState(false); LogEvent("Desconectado."); }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) { if (_serialPort.IsOpen) { _serialPort.Close(); } }
        #endregion
    }
}